const defaults = {
  apiBase: 'https://sub.tisoz.com/v1',
  apiKey: '',
  modelName: 'gpt-image-2',
  geminiModelName: 'gemini-2.5-flash-image',
  apiMode: 'openai',
  authHeader: 'x-api-key',
  responseFormat: 'url',
  imageQuality: 'high',
  stream: false,
  maxRetries: 3,
  retryDelay: 2,
  requestTimeout: 600,
  history: []
};

const sizeOptions = [
  [() => t('defaultSize', '默认（不指定）'), ''],
  ['1024x1024 (1:1)', '1024x1024'],
  ['3840x3840 (1:1)', '3840x3840'],
  ['1024x768 (4:3)', '1024x768'],
  ['1024x576 (16:9)', '1024x576'],
  ['1024x1536 (2:3)', '1024x1536'],
  ['2880x3840 (3:4)', '2880x3840'],
  ['1536x1024 (3:2)', '1536x1024'],
  ['1280x720 (16:9)', '1280x720'],
  ['720x1280 (9:16)', '720x1280']
];

const apiSizeOptions = new Set(['1024x1024', '1024x1536', '1536x1024']);
const geminiAspectRatios = new Set(['1:1', '3:4', '4:3', '9:16', '16:9']);

const HISTORY_LIMIT = 30;
const THUMB_SIZE = 260;
const DB_NAME = 'gpt-image-2-studio';
const DB_VERSION = 1;
const DB_STORE = 'historyImages';

const els = {
  configForm: document.getElementById('configForm'),
  apiBase: document.getElementById('apiBase'),
  apiKey: document.getElementById('apiKey'),
  modelName: document.getElementById('modelName'),
  apiMode: document.getElementById('apiMode'),
  modelOptions: document.getElementById('modelOptions'),
  fetchModels: document.getElementById('fetchModels'),
  authHeader: document.getElementById('authHeader'),
  responseFormat: document.getElementById('responseFormat'),
  imageQuality: document.getElementById('imageQuality'),
  stream: document.getElementById('stream'),
  maxRetries: document.getElementById('maxRetries'),
  retryDelay: document.getElementById('retryDelay'),
  requestTimeout: document.getElementById('requestTimeout'),
  status: document.getElementById('status'),
  historyList: document.getElementById('historyList'),
  toastRoot: document.getElementById('toastRoot')
};

let state = { ...defaults };

init();

async function init() {
  applyI18n();
  state = { ...defaults, ...(await storageGet(Object.keys(defaults))) };
  sanitizeState();
  await migrateLegacyHistory();
  hydrateConfig();
  hydrateSizeSelectors();
  bindEvents();
  bindFilePickers();
  renderHistory();
}

function applyI18n() {
  if (!globalThis.chrome?.i18n) return;
  document.documentElement.lang = chrome.i18n.getUILanguage().startsWith('zh') ? 'zh-CN' : 'en';
  document.querySelectorAll('[data-i18n]').forEach((node) => {
    const message = chrome.i18n.getMessage(node.dataset.i18n);
    if (message) node.textContent = message;
  });
  document.querySelectorAll('[data-i18n-placeholder]').forEach((node) => {
    const message = chrome.i18n.getMessage(node.dataset.i18nPlaceholder);
    if (message) node.placeholder = message;
  });
  const title = t('extensionName', '小肩膀AI图模型插件平台');
  document.title = title;
}

function t(key, fallback, substitutions) {
  const message = globalThis.chrome?.i18n?.getMessage(key, substitutions);
  return message || fallback;
}

function sanitizeState() {
  state.apiBase = normalizeBaseUrl(state.apiBase || defaults.apiBase);
  state.modelName = state.modelName || defaults.modelName;
  state.apiMode = ['openai', 'gemini'].includes(state.apiMode) ? state.apiMode : defaults.apiMode;
  state.authHeader = normalizeAuthHeader(state.authHeader || defaults.authHeader);
  state.responseFormat = ['', 'url', 'b64_json'].includes(state.responseFormat) ? state.responseFormat : defaults.responseFormat;
  state.imageQuality = ['', 'low', 'medium', 'high'].includes(state.imageQuality) ? state.imageQuality : defaults.imageQuality;
  state.stream = Boolean(state.stream);
  state.maxRetries = clampNumber(state.maxRetries, 0, 5, defaults.maxRetries);
  state.retryDelay = clampNumber(state.retryDelay, 1, 30, defaults.retryDelay);
  state.requestTimeout = clampNumber(state.requestTimeout, 10, 600, defaults.requestTimeout);
  state.history = Array.isArray(state.history) ? state.history : [];
}

function hydrateConfig() {
  els.apiBase.value = state.apiBase;
  els.apiKey.value = state.apiKey;
  els.modelName.value = state.modelName;
  els.apiMode.value = state.apiMode;
  els.authHeader.value = state.authHeader;
  els.responseFormat.value = state.responseFormat;
  els.imageQuality.value = state.imageQuality;
  els.stream.checked = state.stream;
  els.maxRetries.value = state.maxRetries;
  els.retryDelay.value = state.retryDelay;
  els.requestTimeout.value = state.requestTimeout;
}

function hydrateSizeSelectors() {
  document.querySelectorAll('select[id$="Size"]').forEach((select) => {
    select.innerHTML = sizeOptions.map(([label, value]) => `<option value="${value}">${typeof label === 'function' ? label() : label}</option>`).join('');
    select.value = '';
  });
}

function bindEvents() {
  document.querySelectorAll('.tab').forEach((tab) => {
    tab.addEventListener('click', () => activateTab(tab.dataset.tab));
  });

  els.configForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    state.apiBase = normalizeBaseUrl(els.apiBase.value.trim());
    state.apiKey = els.apiKey.value.trim();
    state.modelName = els.modelName.value.trim() || defaults.modelName;
    state.apiMode = ['openai', 'gemini'].includes(els.apiMode.value) ? els.apiMode.value : defaults.apiMode;
    state.authHeader = normalizeAuthHeader(els.authHeader.value);
    state.responseFormat = ['', 'url', 'b64_json'].includes(els.responseFormat.value) ? els.responseFormat.value : defaults.responseFormat;
    state.imageQuality = ['', 'low', 'medium', 'high'].includes(els.imageQuality.value) ? els.imageQuality.value : defaults.imageQuality;
    state.stream = els.stream.checked;
    state.maxRetries = clampNumber(els.maxRetries.value, 0, 5, defaults.maxRetries);
    state.retryDelay = clampNumber(els.retryDelay.value, 1, 30, defaults.retryDelay);
    state.requestTimeout = clampNumber(els.requestTimeout.value, 10, 600, defaults.requestTimeout);
    await storageSet({
      apiBase: state.apiBase,
      apiKey: state.apiKey,
      modelName: state.modelName,
      apiMode: state.apiMode,
      authHeader: state.authHeader,
      responseFormat: state.responseFormat,
      imageQuality: state.imageQuality,
      stream: state.stream,
      maxRetries: state.maxRetries,
      retryDelay: state.retryDelay,
      requestTimeout: state.requestTimeout
    });
    hydrateConfig();
    showToast(t('configSaved', '配置已保存。'), 'success');
  });

  els.fetchModels.addEventListener('click', fetchModels);
  els.apiMode.addEventListener('change', syncApiModeModelDefault);
  document.getElementById('textReferenceMode').addEventListener('change', syncTextReferenceMode);
  syncTextReferenceMode();
  document.getElementById('textGenerate').addEventListener('click', generateTextImages);
  document.getElementById('fuseGenerate').addEventListener('click', generateFusion);
  document.getElementById('modifyGenerate').addEventListener('click', generateModify);
  document.getElementById('maskGenerate').addEventListener('click', generateMaskEdit);
  document.getElementById('variationGenerate').addEventListener('click', generateVariation);
  document.getElementById('clearHistory').addEventListener('click', clearHistory);
}

function bindFilePickers() {
  document.querySelectorAll('.file-picker input[type="file"]').forEach((input) => {
    input.addEventListener('change', () => updateFilePickerName(input));
    updateFilePickerName(input);
  });
}

function updateFilePickerName(input) {
  const name = input.closest('.file-picker')?.querySelector('.file-name');
  if (!name) return;
  name.textContent = input.files?.[0]?.name || t('noFileSelected', '未选择文件');
}

function activateTab(name) {
  document.querySelectorAll('.tab').forEach((tab) => tab.classList.toggle('active', tab.dataset.tab === name));
  document.querySelectorAll('.panel').forEach((panel) => panel.classList.toggle('active', panel.dataset.panel === name));
}

function syncTextReferenceMode() {
  const mode = document.getElementById('textReferenceMode').value;
  document.getElementById('textReferenceUrlWrap').classList.toggle('hidden', mode !== 'url');
  document.getElementById('textReferenceFileWrap').classList.toggle('hidden', mode !== 'file');
}

function syncApiModeModelDefault() {
  const currentModel = els.modelName.value.trim();
  if (els.apiMode.value === 'gemini' && (!currentModel || currentModel === defaults.modelName)) {
    els.modelName.value = defaults.geminiModelName;
  }
  if (els.apiMode.value === 'openai' && currentModel === defaults.geminiModelName) {
    els.modelName.value = defaults.modelName;
  }
}

async function generateTextImages() {
  const prompt = document.getElementById('textPrompt').value.trim();
  const size = document.getElementById('textSize').value;
  const count = clampNumber(document.getElementById('textCount').value, 1, 4, 1);
  const reference = getTextReferenceInput();
  const target = document.getElementById('textResults');

  if (!ensureConfig() || !prompt) return showStatus(t('missingPrompt', '请输入提示词。'), 'warn');
  if (reference.mode === 'url' && !reference.urls.length) return showStatus(t('missingReferenceUrl', '请输入参考图 URL。'), 'warn');
  if (reference.mode === 'file' && !reference.file) return showStatus(t('missingReferenceImage', '请上传一张参考图片。'), 'warn');
  clearResults(target);
  await withBusy('textGenerate', t('busyGenerating', '正在生成图片...'), async () => {
    await generateImages({ prompt, size, n: count, reference, onImage: async (image, index) => {
      await renderGeneratedImage(target, image, { prompt, size, source: '文生图', prefix: 'generated' }, index, count);
    } });
  });
}

async function generateFusion() {
  const image1 = document.getElementById('fuseImage1').files[0];
  const image2 = document.getElementById('fuseImage2').files[0];
  const prompt = document.getElementById('fusePrompt').value.trim();
  const size = document.getElementById('fuseSize').value;
  const target = document.getElementById('fuseResults');

  if (!ensureConfig()) return;
  if (!image1 || !image2) return showStatus(t('missingFuseImages', '请上传两张图片。'), 'warn');
  if (!prompt) return showStatus(t('missingFusePrompt', '请输入融合提示词。'), 'warn');
  clearResults(target);
  await withBusy('fuseGenerate', t('busyFusing', '正在融合图片...'), async () => {
    const combinedBlob = await combineImagesSideBySide(image1, image2);
    await editImages({ image: combinedBlob, images: [image1, image2], prompt, size, n: 1, onImage: async (imageData, index) => {
      await renderGeneratedImage(target, imageData, { prompt: `(图片融合) ${prompt}`, size, source: '图片融合', prefix: 'fused' }, index, 1);
    } });
  });
}

async function generateModify() {
  const image = document.getElementById('modifyImage').files[0];
  const prompt = document.getElementById('modifyPrompt').value.trim();
  const size = document.getElementById('modifySize').value;
  const target = document.getElementById('modifyResults');

  if (!ensureConfig()) return;
  if (!image) return showStatus(t('missingSingleImage', '请上传一张图片。'), 'warn');
  if (!prompt) return showStatus(t('missingModifyPrompt', '请输入修改提示词。'), 'warn');
  clearResults(target);
  await withBusy('modifyGenerate', t('busyModifying', '正在修改图片...'), async () => {
    const normalized = await normalizeImageBlob(image);
    await editImages({ image: normalized, prompt, size, n: 1, onImage: async (imageData) => {
      await renderBeforeAfter(target, image, imageData, { prompt: `(提示词修改) ${prompt}`, size, source: '提示词修改', prefix: 'modified' });
    } });
  });
}

async function generateMaskEdit() {
  const image = document.getElementById('maskImage').files[0];
  const mask = document.getElementById('maskFile').files[0];
  const prompt = document.getElementById('maskPrompt').value.trim();
  const size = document.getElementById('maskSize').value;
  const target = document.getElementById('maskResults');

  if (!ensureConfig()) return;
  if (!image || !mask) return showStatus(t('missingMaskImages', '请上传原图和遮罩图。'), 'warn');
  if (!prompt) return showStatus(t('missingEditPrompt', '请输入编辑提示词。'), 'warn');
  clearResults(target);
  await withBusy('maskGenerate', t('busyEditing', '正在编辑图像...'), async () => {
    const normalizedImage = await normalizeImageBlob(image);
    const normalizedMask = await normalizeImageBlob(mask);
    await editImages({ image: normalizedImage, mask: normalizedMask, prompt, size, n: 1, onImage: async (imageData, index) => {
      await renderGeneratedImage(target, imageData, { prompt, size, source: '图像编辑', prefix: 'edited' }, index, 1);
    } });
  });
}

async function generateVariation() {
  const image = document.getElementById('variationImage').files[0];
  const promptInput = document.getElementById('variationPrompt').value.trim();
  const prompt = promptInput || 'Generate a creative variation of this image. Keep the same subject and overall style, but introduce subtle differences in composition, lighting, or details.';
  const size = document.getElementById('variationSize').value;
  const count = clampNumber(document.getElementById('variationCount').value, 1, 4, 1);
  const target = document.getElementById('variationResults');

  if (!ensureConfig()) return;
  if (!image) return showStatus(t('missingReferenceImage', '请上传一张参考图片。'), 'warn');
  clearResults(target);
  await withBusy('variationGenerate', t('busyVariation', '正在生成变体...'), async () => {
    const normalized = await normalizeImageBlob(image);
    await editImages({ image: normalized, prompt, size, n: count, onImage: async (imageData, index) => {
      await renderGeneratedImage(target, imageData, { prompt: `(变体生成) ${prompt}`, size, source: '图像变体', prefix: 'variation' }, index, count);
    } });
  });
}

async function generateImages({ prompt, size, n, reference, onImage }) {
  const context = getRequestContext();
  const images = [];

  for (let index = 0; index < n; index++) {
    showStatus(`正在生成第 ${index + 1}/${n} 张图片...`, 'warn');
    const data = state.apiMode === 'gemini'
      ? await apiGemini(buildGeminiPayload({ prompt, size, imageParts: await getGeminiReferenceParts(reference) }), context)
      : reference?.mode === 'file'
        ? await apiForm('/images/edits', buildTextReferenceForm({ image: await normalizeImageBlob(reference.file), prompt, size, n: 1 }), context)
        : await apiJson('/images/generations', buildGenerationPayload({ prompt, size, n: 1, imageUrls: reference?.urls || [] }), context);
    const [image] = await postProcessImages(decodeImages(data), size);
    if (!image) continue;
    images.push(image);
    if (onImage) await onImage(image, index);
  }

  return images;
}

async function editImages({ image, images: inputImages, mask, prompt, size, n, onImage }) {
  const context = getRequestContext();
  const images = [];

  for (let index = 0; index < n; index++) {
    showStatus(`正在生成第 ${index + 1}/${n} 张图片...`, 'warn');
    const data = state.apiMode === 'gemini'
      ? await apiGemini(buildGeminiPayload({ prompt, size, imageParts: await getGeminiImageParts(inputImages || [image, mask].filter(Boolean)) }), context)
      : await apiForm('/images/edits', buildEditForm({ image, mask, prompt, size, n: 1 }), context);
    const [nextImage] = await postProcessImages(decodeImages(data), size);
    if (!nextImage) continue;
    images.push(nextImage);
    if (onImage) await onImage(nextImage, index);
  }

  return images;
}

function buildGenerationPayload({ prompt, size, n, imageUrls = [] }) {
  const payload = {
    model: state.modelName,
    prompt,
    n
  };
  const apiSize = getApiImageSize(size);
  if (apiSize) payload.size = apiSize;
  if (state.imageQuality) payload.quality = state.imageQuality;
  if (state.responseFormat) payload.response_format = state.responseFormat;
  payload.stream = true;
  if (imageUrls.length) payload.image = imageUrls;
  return prepareImagePayload(payload);
}

function buildTextReferenceForm({ image, prompt, size, n }) {
  return buildEditForm({ image, prompt, size, n });
}

function buildEditForm({ image, mask, prompt, size, n }) {
  const form = new FormData();
  const responseFormat = getSupportedResponseFormat(state.modelName, state.responseFormat);
  form.append('model', state.modelName);
  form.append('image', image, 'image.png');
  if (mask) form.append('mask', mask, 'mask.png');
  form.append('prompt', prompt);
  const apiSize = getApiImageSize(size);
  if (apiSize) form.append('size', apiSize);
  if (state.imageQuality) form.append('quality', state.imageQuality);
  if (responseFormat) form.append('response_format', responseFormat);
  form.append('stream', 'true');
  form.append('n', String(n));
  return form;
}

function buildGeminiPayload({ prompt, size, imageParts = [] }) {
  return {
    contents: [{ parts: [{ text: prompt }, ...imageParts] }],
    generationConfig: {
      responseModalities: ['IMAGE'],
      imageConfig: {
        aspectRatio: getGeminiAspectRatio(size),
        imageSize: '1K'
      }
    }
  };
}

async function getGeminiReferenceParts(reference) {
  if (reference?.mode === 'file') return getGeminiImageParts([reference.file]);
  if (reference?.mode !== 'url') return [];

  const parts = [];
  for (const url of reference.urls) {
    const dataUrl = await fetchImageAsDataUrl(url);
    if (!dataUrl) throw new Error(t('geminiReferenceUrlFailed', 'Gemini 无法读取参考图 URL，请检查图片地址或改为上传文件。'));
    parts.push(dataUrlToGeminiPart(dataUrl));
  }
  return parts;
}

async function getGeminiImageParts(images) {
  const parts = [];
  for (const image of images.filter(Boolean)) {
    parts.push(dataUrlToGeminiPart(await blobToDataUrl(image)));
  }
  return parts;
}

function dataUrlToGeminiPart(dataUrl) {
  const match = String(dataUrl).match(/^data:([^;]+);base64,(.+)$/);
  if (!match) throw new Error(t('invalidImageData', '图片数据格式无效。'));
  return {
    inlineData: {
      mimeType: match[1],
      data: match[2]
    }
  };
}

function getGeminiAspectRatio(size) {
  const normalized = normalizeImageSize(size);
  if (!normalized) return '1:1';
  const { width, height } = parseImageSize(normalized);
  const divisor = gcd(width, height);
  const exactRatio = `${width / divisor}:${height / divisor}`;
  if (geminiAspectRatios.has(exactRatio)) return exactRatio;

  const targetRatio = width / height;
  return [...geminiAspectRatios].reduce((closest, ratio) => {
    const [ratioWidth, ratioHeight] = ratio.split(':').map(Number);
    const closestDiff = Math.abs(targetRatio - closest.width / closest.height);
    const nextDiff = Math.abs(targetRatio - ratioWidth / ratioHeight);
    return nextDiff < closestDiff ? { value: ratio, width: ratioWidth, height: ratioHeight } : closest;
  }, { value: '1:1', width: 1, height: 1 }).value;
}

function gcd(a, b) {
  return b === 0 ? a : gcd(b, a % b);
}

function prepareImagePayload(payload) {
  const nextPayload = { ...payload };
  const responseFormat = getSupportedResponseFormat(nextPayload.model, nextPayload.response_format);
  if (responseFormat) nextPayload.response_format = responseFormat;
  else delete nextPayload.response_format;
  return nextPayload;
}

function getSupportedResponseFormat(model, responseFormat) {
  if (isGptImageModel(model) && responseFormat === 'url') return '';
  return responseFormat || '';
}

function isGptImageModel(model) {
  return String(model || '').startsWith('gpt-image-');
}

async function fetchModels() {
  const baseUrl = normalizeBaseUrl(els.apiBase.value.trim());
  const apiKey = els.apiKey.value.trim();
  const authHeader = normalizeAuthHeader(els.authHeader.value);

  if (!baseUrl) return showStatus(t('missingApiBase', '请输入第三方 API Base URL 并保存配置。'), 'warn');
  if (!apiKey) return showStatus(t('missingApiKey', '请先在左侧输入 API Key 并保存配置。'), 'warn');

  await withBusy('fetchModels', t('busyFetchingModels', '正在获取模型...'), async () => {
    const context = { baseUrl, timeoutSeconds: clampNumber(els.requestTimeout.value, 10, 600, defaults.requestTimeout) };
    const data = await apiGetModels(context, authHeader, apiKey);
    const models = extractModelIds(data);
    if (!models.length) throw new Error(t('noModelsFound', '接口返回成功，但没有找到模型名称。'));
    hydrateModelOptions(models);
    if (!els.modelName.value.trim()) els.modelName.value = models[0];
    showToast(t('modelsLoaded', '模型列表已获取。'), 'success');
  });
}

async function apiGetModels(context, authHeader, apiKey) {
  try {
    return await requestWithRetry(buildPlainApiUrl(context, '/models'), {
      method: 'GET',
      headers: buildRequestHeadersForKey({ json: true, authHeader, apiKey })
    }, context);
  } catch {
    return requestWithRetry(buildPlainApiUrl(context, '/model'), {
      method: 'GET',
      headers: buildRequestHeadersForKey({ json: true, authHeader, apiKey })
    }, context);
  }
}

function extractModelIds(data) {
  const source = Array.isArray(data) ? data : data?.data || data?.models || data?.model || [];
  return (Array.isArray(source) ? source : [source])
    .map((item) => typeof item === 'string' ? item : item?.id || item?.name || item?.model || '')
    .filter(Boolean);
}

function hydrateModelOptions(models) {
  els.modelOptions.replaceChildren(...models.map((model) => {
    const option = document.createElement('option');
    option.value = model;
    return option;
  }));
}

function getTextReferenceInput() {
  const mode = document.getElementById('textReferenceMode').value;
  if (mode === 'url') {
    return {
      mode,
      urls: document.getElementById('textReferenceUrls').value
        .split(/\r?\n/)
        .map((url) => url.trim())
        .filter(Boolean)
    };
  }
  if (mode === 'file') {
    return {
      mode,
      file: document.getElementById('textReferenceFile').files[0]
    };
  }
  return { mode: 'none', urls: [] };
}

function normalizeImageSize(size) {
  return sizeOptions.some(([, value]) => value === size) ? size : '';
}

function getApiImageSize(size) {
  const normalized = normalizeImageSize(size);
  if (!normalized) return '';
  if (apiSizeOptions.has(normalized)) return normalized;
  const { width, height } = parseImageSize(normalized);
  if (width > height) return '1536x1024';
  if (height > width) return '1024x1536';
  return '1024x1024';
}

function parseImageSize(size) {
  const normalized = normalizeImageSize(size);
  const [width, height] = normalized.split('x').map(Number);
  return { width, height };
}

function getRequestContext() {
  return {
    baseUrl: state.apiBase,
    timeoutSeconds: state.requestTimeout
  };
}

async function apiJson(path, payload, context) {
  return requestWithRetry(buildApiUrl(context, path), {
    method: 'POST',
    headers: buildRequestHeaders({ json: true }),
    body: JSON.stringify(payload)
  }, context);
}

async function apiForm(path, form, context) {
  return requestWithRetry(buildApiUrl(context, path), {
    method: 'POST',
    headers: buildRequestHeaders({ json: false }),
    body: form
  }, context);
}

async function apiGemini(payload, context) {
  return requestWithRetry(buildGeminiApiUrl(context), {
    method: 'POST',
    headers: buildRequestHeaders({ json: true }),
    body: JSON.stringify(payload)
  }, context);
}

function buildApiUrl(context, path) {
  const url = new URL(`${context.baseUrl}${path}`);
  url.searchParams.set('stream', 'true');
  return url.toString();
}

function buildPlainApiUrl(context, path) {
  return new URL(`${context.baseUrl}${path}`).toString();
}

function buildGeminiApiUrl(context) {
  const baseUrl = context.baseUrl.replace(/\/(v1|v1beta)\/?$/, '');
  const model = encodeURIComponent(normalizeGeminiModelName(state.modelName || 'gemini-2.5-flash-image'));
  return `${baseUrl}/v1beta/models/${model}:streamGenerateContent`;
}

function normalizeGeminiModelName(model) {
  return String(model || '').replace(/^models\//, '');
}

function buildRequestHeaders({ json }) {
  return buildRequestHeadersForKey({ json, authHeader: state.authHeader, apiKey: state.apiKey });
}

function buildRequestHeadersForKey({ json, authHeader, apiKey }) {
  const headers = { Accept: 'application/json, text/event-stream' };
  if (json) headers['Content-Type'] = 'application/json';
  if (authHeader === 'Authorization') headers.Authorization = `Bearer ${apiKey}`;
  else headers[authHeader] = apiKey;
  return headers;
}

async function requestWithRetry(url, options, context) {
  let lastError;
  for (let attempt = 0; attempt <= state.maxRetries; attempt++) {
    const controller = new AbortController();
    let timedOut = false;
    const timeout = window.setTimeout(() => {
      timedOut = true;
      controller.abort();
    }, context.timeoutSeconds * 1000);

    try {
      const response = await fetch(url, { ...options, signal: controller.signal });
      window.clearTimeout(timeout);
      if (!response.ok) {
        const detail = await safeReadError(response);
        const message = formatApiError(response.status, detail);
        if ([502, 503, 504].includes(response.status) && attempt < state.maxRetries) {
          await waitBeforeRetry(attempt, response.status);
          continue;
        }
        throw new Error(message);
      }
      return parseApiResponse(response);
    } catch (error) {
      lastError = timedOut || error.name === 'AbortError'
        ? new Error(t('requestTimeoutMessage', '请求超时：第三方服务可能仍在后台处理，请避免立即重复提交。'))
        : error;
      if (lastError.message === t('requestTimeoutMessage', '请求超时：第三方服务可能仍在后台处理，请避免立即重复提交。')) throw lastError;
      if (attempt < state.maxRetries && shouldRetryNetworkError(error)) {
        await waitBeforeRetry(attempt, '网络错误');
        continue;
      }
      throw lastError;
    } finally {
      window.clearTimeout(timeout);
    }
  }
  throw lastError;
}

async function parseApiResponse(response) {
  const contentType = response.headers.get('content-type') || '';
  if (contentType.includes('text/event-stream')) return parseSseResponse(response);
  return response.json();
}

async function parseSseResponse(response) {
  const reader = response.body?.getReader();
  if (!reader) return { data: [] };
  const decoder = new TextDecoder();
  const images = [];
  let buffer = '';

  showStatus(t('receivingStream', '正在接收流式响应...'), 'warn');
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split(/\r?\n/);
    buffer = lines.pop() || '';
    collectSseImages(lines, images);
  }
  buffer += decoder.decode();
  if (buffer) collectSseImages(buffer.split(/\r?\n/), images);
  return { data: images };
}

function collectSseImages(lines, images) {
  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line.startsWith('data:')) continue;
    const json = line.slice(5).trim();
    if (!json || json === '[DONE]') continue;
    try {
      const event = JSON.parse(json);
      if (Array.isArray(event.data)) images.push(...event.data);
      else if (event.url || event.b64_json || event.b64) images.push(event);
      else images.push(...extractGeminiImages(event));
    } catch {
      // Ignore malformed stream fragments from proxy services.
    }
  }
}

function decodeImages(data) {
  if (data?.candidates?.length) return extractGeminiImages(data).map(decodeImageItem).filter(Boolean);
  if (!data?.data?.length) return [];
  return data.data.map(decodeImageItem).filter(Boolean);
}

function extractGeminiImages(data) {
  const parts = data?.candidates?.flatMap((candidate) => candidate?.content?.parts || []) || [];
  return parts
    .map((part) => part?.inlineData || part?.inline_data)
    .filter((inlineData) => inlineData?.data)
    .map((inlineData) => ({ b64: inlineData.data, mimeType: inlineData.mimeType || inlineData.mime_type || 'image/png' }));
}

function decodeImageItem(item) {
  if (item.url) return item.url;
  const b64 = item.b64_json || item.b64;
  if (!b64) return '';
  if (String(b64).startsWith('data:')) return b64;
  return `data:${item.mimeType || 'image/png'};base64,${b64}`;
}

async function postProcessImages(images, size) {
  const outputSize = normalizeImageSize(size);
  if (!outputSize) return images;
  const apiSize = getApiImageSize(outputSize);
  if (outputSize === apiSize) return images;
  return Promise.all(images.map(async (image) => {
    if (isRemoteUrl(image)) return image;
    return resizeImageDataUrl(image, outputSize);
  }));
}

async function resizeImageDataUrl(dataUrl, size) {
  const { width, height } = parseImageSize(size);
  const img = await loadImageFromUrl(dataUrl);
  const sourceRatio = img.naturalWidth / img.naturalHeight;
  const targetRatio = width / height;
  let sx = 0;
  let sy = 0;
  let sw = img.naturalWidth;
  let sh = img.naturalHeight;

  if (sourceRatio > targetRatio) {
    sw = Math.round(img.naturalHeight * targetRatio);
    sx = Math.round((img.naturalWidth - sw) / 2);
  } else if (sourceRatio < targetRatio) {
    sh = Math.round(img.naturalWidth / targetRatio);
    sy = Math.round((img.naturalHeight - sh) / 2);
  }

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(img, sx, sy, sw, sh, 0, 0, width, height);
  return canvas.toDataURL('image/png');
}

async function renderGeneratedImage(target, dataUrl, meta, index, total) {
  const filename = `${meta.prefix}_${timestamp()}_${index + 1}.png`;
  target.appendChild(createResultCard(dataUrl, `${meta.source} ${index + 1}`, filename));
  await saveHistory({ ...meta, image: dataUrl });
  showStatus(`已生成 ${index + 1}/${total} 张图片。`, index + 1 === total ? 'success' : 'warn');
}

async function renderGeneratedImages(target, images, meta) {
  if (!images.length) {
    showStatus('未生成任何图片。', 'error');
    return;
  }

  for (let index = 0; index < images.length; index++) {
    await renderGeneratedImage(target, images[index], meta, index, images.length);
  }
}

async function renderBeforeAfter(target, beforeFile, afterDataUrl, meta) {
  const beforeUrl = URL.createObjectURL(beforeFile);
  const wrap = document.createElement('div');
  const grid = document.createElement('div');
  const before = createImageComparisonItem(beforeUrl, '原图', '原图');
  const after = createImageComparisonItem(afterDataUrl, '修改结果', '修改结果');
  const download = document.createElement('button');

  wrap.className = 'result-card';
  grid.className = 'results';
  download.type = 'button';
  download.textContent = '下载图片';
  download.addEventListener('click', () => downloadImage(afterDataUrl, `modified_${timestamp()}.png`));
  after.querySelector('.result-actions').appendChild(download);
  grid.append(before, after);
  wrap.appendChild(grid);
  target.appendChild(wrap);
  await saveHistory({ ...meta, image: afterDataUrl });
  showStatus('修改完成。', 'success');
}

function createImageComparisonItem(src, alt, label) {
  const item = document.createElement('div');
  const img = document.createElement('img');
  const actions = document.createElement('div');
  const caption = document.createElement('span');
  img.src = src;
  img.alt = alt;
  actions.className = 'result-actions';
  caption.textContent = label;
  actions.appendChild(caption);
  item.append(img, actions);
  return item;
}

function createResultCard(dataUrl, caption, filename) {
  const card = document.createElement('article');
  const img = document.createElement('img');
  const actions = document.createElement('div');
  const label = document.createElement('span');
  const button = document.createElement('button');

  card.className = 'result-card';
  img.src = dataUrl;
  img.alt = caption;
  actions.className = 'result-actions';
  label.textContent = caption;
  button.className = 'ghost';
  button.type = 'button';
  button.textContent = '下载图片';
  button.addEventListener('click', () => downloadImage(dataUrl, filename));
  actions.append(label, button);
  card.append(img, actions);
  return card;
}

async function migrateLegacyHistory() {
  const legacyItems = state.history.filter((record) => record.image && !record.thumb);
  if (!legacyItems.length) return;

  for (const record of legacyItems) {
    record.id = record.id || crypto.randomUUID();
    await imageDbPut(record.id, record.image);
    record.thumb = await makeThumbnail(record.image);
    delete record.image;
  }
  state.history = state.history.slice(0, HISTORY_LIMIT);
  await storageSet({ history: state.history });
}

async function saveHistory(record) {
  const id = crypto.randomUUID();
  const localImage = isRemoteUrl(record.image) ? await fetchImageAsDataUrl(record.image) : record.image;
  if (localImage) await imageDbPut(id, localImage);
  const item = {
    id,
    timestamp: new Date().toLocaleString(document.documentElement.lang || 'zh-CN', { hour12: false }),
    prompt: record.prompt,
    thumb: localImage ? await makeThumbnail(localImage) : record.image,
    remoteUrl: localImage ? '' : record.image,
    source: record.source,
    size: record.size
  };
  const nextHistory = [item, ...state.history].slice(0, HISTORY_LIMIT);
  const removed = state.history.slice(HISTORY_LIMIT - 1);
  state.history = nextHistory;
  await storageSet({ history: state.history });
  await Promise.all(removed.map((oldRecord) => imageDbDelete(oldRecord.id)));
  renderHistory();
}

function renderHistory() {
  if (!state.history.length) {
    els.historyList.innerHTML = '<div class="card">暂无生成记录，开始生成图片后会自动保存到这里。</div>';
    return;
  }

  const fragment = document.createDocumentFragment();
  state.history.forEach((record) => {
    fragment.appendChild(createHistoryCard(record));
  });
  els.historyList.replaceChildren(fragment);
}

function createHistoryCard(record) {
  const card = document.createElement('article');
  const img = document.createElement('img');
  const body = document.createElement('div');
  const title = document.createElement('h4');
  const prompt = document.createElement('p');
  const size = document.createElement('p');
  const actions = document.createElement('div');
  const download = createHistoryButton('download', '下载图片');
  const variation = createHistoryButton('variation', '用于变体');
  const edit = createHistoryButton('edit', '用于提示词修改');

  card.className = 'history-card';
  img.src = record.thumb || record.image || record.remoteUrl || '';
  img.loading = 'lazy';
  img.decoding = 'async';
  img.alt = '历史图片';
  title.textContent = `${record.timestamp} · ${record.source}`;
  prompt.append(document.createElement('b'), document.createTextNode(record.prompt || ''));
  prompt.querySelector('b').textContent = '提示词：';
  size.append(document.createElement('b'), document.createTextNode(record.size || ''));
  size.querySelector('b').textContent = '尺寸：';
  actions.className = 'history-actions';
  actions.append(download, variation, edit);
  body.append(title, prompt, size, actions);
  card.append(img, body);

  download.addEventListener('click', async () => {
    const image = await getHistoryImage(record);
    downloadImage(image, `${record.source}_${record.id}.png`);
  });
  variation.addEventListener('click', async () => {
    const image = await getReusableHistoryImage(record);
    if (!image) return;
    await dataUrlToFileInput(image, 'variationImage', 'history.png');
    activateTab('variation');
    showStatus('历史图片已载入图像变体。', 'success');
  });
  edit.addEventListener('click', async () => {
    const image = await getReusableHistoryImage(record);
    if (!image) return;
    await dataUrlToFileInput(image, 'modifyImage', 'history.png');
    activateTab('modify');
    showStatus('历史图片已载入提示词修改。', 'success');
  });

  return card;
}

function createHistoryButton(action, label) {
  const button = document.createElement('button');
  button.className = 'ghost';
  button.dataset.action = action;
  button.type = 'button';
  button.textContent = label;
  return button;
}

async function clearHistory() {
  const ids = state.history.map((record) => record.id);
  state.history = [];
  await storageSet({ history: [] });
  await Promise.all(ids.map((id) => imageDbDelete(id)));
  renderHistory();
  showStatus('历史记录已清空。', 'success');
}

function ensureConfig() {
  if (!state.apiKey) {
    showStatus('请先在左侧输入 API Key 并保存配置。', 'warn');
    return false;
  }
  if (!state.apiBase) {
    showStatus('请输入第三方 API Base URL 并保存配置。', 'warn');
    return false;
  }
  return true;
}

async function withBusy(buttonId, busyText, task) {
  const button = document.getElementById(buttonId);
  const original = button.textContent;
  button.disabled = true;
  button.textContent = busyText;
  showStatus(busyText, 'warn');
  try {
    await task();
  } catch (error) {
    showStatus(error.message || String(error), 'error');
  } finally {
    button.disabled = false;
    button.textContent = original;
  }
}

function clearResults(target) {
  target.innerHTML = '';
}

function showStatus(message, type = 'success') {
  els.status.textContent = message;
  els.status.className = `status ${type}`;
  window.clearTimeout(showStatus.timer);
  if (type === 'success') {
    showStatus.timer = window.setTimeout(() => els.status.classList.add('hidden'), 4500);
  }
}

function showToast(message, type = 'success') {
  window.clearTimeout(showToast.timer);
  els.toastRoot.replaceChildren();
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <div class="toast-copy">${escapeHtml(message)}</div>
    <button class="toast-close" type="button" aria-label="${escapeHtml(t('close', '关闭'))}">×</button>
  `;
  const close = () => {
    toast.classList.add('closing');
    window.setTimeout(() => toast.remove(), 180);
  };
  toast.querySelector('button').addEventListener('click', close);
  els.toastRoot.appendChild(toast);
  showToast.timer = window.setTimeout(close, 5000);
}

function normalizeBaseUrl(value) {
  return String(value || '').replace(/\/+$/, '');
}

function normalizeAuthHeader(value) {
  const header = String(value || '').trim();
  if (/^authorization$/i.test(header)) return 'Authorization';
  if (/^x-api-key$/i.test(header)) return 'x-api-key';
  return /^[A-Za-z0-9-]+$/.test(header) ? header : defaults.authHeader;
}

function clampNumber(value, min, max, fallback) {
  const num = Number(value);
  if (!Number.isFinite(num)) return fallback;
  return Math.min(max, Math.max(min, Math.trunc(num)));
}

function shouldRetryNetworkError(error) {
  return !/^API 请求失败/.test(error.message || '') && error.name !== 'AbortError';
}

async function waitBeforeRetry(attempt, reason) {
  const delay = state.retryDelay * 2 ** attempt;
  showStatus(`服务暂时不可用（${reason}），第 ${attempt + 1}/${state.maxRetries} 次重试，等待 ${delay} 秒...`, 'warn');
  await new Promise((resolve) => setTimeout(resolve, delay * 1000));
}

async function safeReadError(response) {
  const text = await response.text();
  const contentType = response.headers.get('content-type') || '';
  const trimmed = text.trim();

  if (contentType.includes('text/html') || /^<!doctype html/i.test(trimmed) || /^<html/i.test(trimmed)) {
    if (/cloudflare/i.test(trimmed) && /bad gateway/i.test(trimmed)) {
      return 'Cloudflare 返回 Bad gateway，API 源站暂时不可用。';
    }
    if (/cloudflare/i.test(trimmed) && /timeout occurred/i.test(trimmed)) {
      return 'Cloudflare 等待 API 源站响应超时，服务端任务耗时过长或负载过高。';
    }
    return '服务端返回了 HTML 错误页。';
  }

  try {
    const parsed = JSON.parse(text);
    return parsed?.error?.message || parsed?.message || text;
  } catch {
    return text;
  }
}

function formatApiError(status, detail) {
  const messages = {
    400: '请求无效：可能是提示词违规或参数格式错误。',
    401: '认证失败：请检查 API Key 是否正确。',
    402: '需要付费：账户余额不足或计划受限。',
    403: '禁止访问：API Key 无权使用该资源或端点。',
    404: '端点不存在：请检查 API Base URL 和模型名称是否正确。',
    413: '请求体过大：提示词或上传图片可能太大，请缩短提示词或压缩上传图片。',
    415: '不支持的媒体类型：图片格式可能不正确。',
    422: '请求参数错误：提供的参数无法处理。',
    429: '请求过于频繁：请稍后重试。',
    500: '服务器错误：第三方服务暂时不可用。',
    502: '服务器错误：第三方服务暂时不可用。',
    503: '服务器错误：第三方服务暂时不可用。',
    504: '服务器错误：第三方服务暂时不可用。',
    524: '服务器超时：第三方服务处理时间过长。'
  };
  return `API 请求失败 (${status})：${messages[status] || '未知错误。'}${detail ? ` 详细信息：${detail}` : ''}`;
}

async function normalizeImageBlob(file) {
  const bitmap = await createImageBitmap(file);
  const canvas = document.createElement('canvas');
  canvas.width = bitmap.width;
  canvas.height = bitmap.height;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(bitmap, 0, 0);
  return new Promise((resolve) => canvas.toBlob(resolve, 'image/png'));
}

async function combineImagesSideBySide(file1, file2) {
  const [img1, img2] = await Promise.all([loadImage(file1), loadImage(file2)]);
  const maxH = Math.max(img1.naturalHeight, img2.naturalHeight);
  const w1 = Math.round(img1.naturalWidth * maxH / img1.naturalHeight);
  const w2 = Math.round(img2.naturalWidth * maxH / img2.naturalHeight);
  const canvas = document.createElement('canvas');
  canvas.width = w1 + w2;
  canvas.height = maxH;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(img1, 0, 0, w1, maxH);
  ctx.drawImage(img2, w1, 0, w2, maxH);
  return new Promise((resolve) => canvas.toBlob(resolve, 'image/png'));
}

function loadImage(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = url;
  });
}

function downloadImage(dataUrl, filename) {
  chrome.downloads.download({ url: dataUrl, filename, saveAs: false });
}

async function getHistoryImage(record) {
  return await imageDbGet(record.id) || record.image || record.thumb || record.remoteUrl;
}

async function getReusableHistoryImage(record) {
  const image = await getHistoryImage(record);
  if (!isRemoteUrl(image)) return image;
  const dataUrl = await fetchImageAsDataUrl(image);
  if (dataUrl) return dataUrl;
  showStatus(t('remoteImageReuseBlocked', '远程图片受跨域限制，无法直接用于变体或修改。请先下载后手动上传。'), 'warn');
  return '';
}

async function makeThumbnail(dataUrl) {
  const img = await loadImageFromUrl(dataUrl);
  const scale = Math.min(1, THUMB_SIZE / Math.max(img.naturalWidth, img.naturalHeight));
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(img.naturalWidth * scale));
  canvas.height = Math.max(1, Math.round(img.naturalHeight * scale));
  const ctx = canvas.getContext('2d', { alpha: false });
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL('image/jpeg', 0.72);
}

function loadImageFromUrl(url) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = url;
  });
}

function isRemoteUrl(value) {
  return /^https?:\/\//i.test(String(value || ''));
}

async function fetchImageAsDataUrl(url) {
  try {
    const response = await fetch(url);
    if (!response.ok) return '';
    const blob = await response.blob();
    return await blobToDataUrl(blob);
  } catch {
    return '';
  }
}

function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

async function dataUrlToFileInput(dataUrl, inputId, filename) {
  const blob = await (await fetch(dataUrl)).blob();
  const file = new File([blob], filename, { type: blob.type || 'image/png' });
  const transfer = new DataTransfer();
  transfer.items.add(file);
  const input = document.getElementById(inputId);
  input.files = transfer.files;
  input.dispatchEvent(new Event('change', { bubbles: true }));
}

function timestamp() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  }[char]));
}

function storageGet(keys) {
  return new Promise((resolve) => chrome.storage.local.get(keys, resolve));
}

function storageSet(value) {
  return new Promise((resolve) => chrome.storage.local.set(value, resolve));
}

function openImageDb() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      request.result.createObjectStore(DB_STORE);
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function imageDbPut(id, image) {
  const db = await openImageDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(DB_STORE, 'readwrite');
    tx.objectStore(DB_STORE).put(image, id);
    tx.oncomplete = () => {
      db.close();
      resolve();
    };
    tx.onerror = () => {
      db.close();
      reject(tx.error);
    };
  });
}

async function imageDbGet(id) {
  const db = await openImageDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(DB_STORE, 'readonly');
    const request = tx.objectStore(DB_STORE).get(id);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
    tx.oncomplete = () => db.close();
  });
}

async function imageDbDelete(id) {
  const db = await openImageDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(DB_STORE, 'readwrite');
    tx.objectStore(DB_STORE).delete(id);
    tx.oncomplete = () => {
      db.close();
      resolve();
    };
    tx.onerror = () => {
      db.close();
      reject(tx.error);
    };
  });
}
